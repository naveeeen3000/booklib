def add(a, v):
    return a + v